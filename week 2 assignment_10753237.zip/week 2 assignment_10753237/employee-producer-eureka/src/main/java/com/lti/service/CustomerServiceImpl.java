package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.entity.Customer;
import com.lti.repository.ProducerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	
	@Autowired
	private ProducerRepository repository;
	@Override
	public Customer save(Customer customer) {
		return repository.save(customer);
	}

	@Override
	public Customer getByid(Integer id) {
		 Customer c=repository.findOne(id);
		 if(c!=null) {
			 return c;
		 }
		return null;
	}

	@Override
	public List<Customer> getAll() {
	
		return repository.findAll();
	}

	@Override
	public boolean deleteById(Integer id) {
		
		Customer c=repository.findOne(id);
		if(c!=null) {
			repository.delete(c);
			return true;
		}
		return false;
	}

	@Override
	public boolean update(Customer customer) {
		if(customer!=null) {
			Customer c=repository.findOne(customer.getId());
			repository.save(c);
		}
		return false;
	}

}
